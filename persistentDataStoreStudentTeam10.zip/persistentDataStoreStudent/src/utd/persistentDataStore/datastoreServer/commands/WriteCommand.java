package utd.persistentDataStore.datastoreServer.commands;

import java.io.IOException;

import utd.persistentDataStore.utils.FileUtil;
import utd.persistentDataStore.utils.ServerException;
import utd.persistentDataStore.utils.StreamUtil;

public class WriteCommand extends ServerCommand {
	
	public void run() throws IOException, ServerException {
		
		String name = StreamUtil.readLine(inputStream);
		System.out.println(name);
		int byteSize = Integer.parseInt(StreamUtil.readLine(inputStream));
		byte[] byteArray= StreamUtil.readData(byteSize, inputStream);
		FileUtil.writeData(name, byteArray);
		sendOK();
		
	}
}
