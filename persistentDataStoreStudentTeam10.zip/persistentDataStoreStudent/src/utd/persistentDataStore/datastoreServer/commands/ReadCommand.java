package utd.persistentDataStore.datastoreServer.commands;

import java.io.IOException;
import utd.persistentDataStore.utils.FileUtil;
import utd.persistentDataStore.utils.*;


public class ReadCommand extends ServerCommand {
	
	public void run() throws  IOException, ServerException {
		System.out.println("Before Read");
		String name = StreamUtil.readLine(inputStream);
		System.out.println("After Read");
		byte [] byteArray = FileUtil.readData(name);
		sendOK();
		System.out.println("OK");
		StreamUtil.writeLine(byteArray.length + "", outputStream);
		StreamUtil.writeData(byteArray, outputStream);
	}

}
