package utd.persistentDataStore.datastoreServer.commands;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import utd.persistentDataStore.utils.FileUtil;
import utd.persistentDataStore.utils.ServerException;
import utd.persistentDataStore.utils.StreamUtil;

public class DirectoryCommand extends ServerCommand {

	@Override
	public void run() throws IOException, ServerException {
		// TODO Auto-generated method stub
		List<String> directory = FileUtil.directory();
		sendOK();
		StreamUtil.writeLine(directory.size() + "", outputStream);
		for (int i =0; i < directory.size(); i ++) {
			StreamUtil.writeLine(directory.get(i), outputStream);
		}
	}

}
