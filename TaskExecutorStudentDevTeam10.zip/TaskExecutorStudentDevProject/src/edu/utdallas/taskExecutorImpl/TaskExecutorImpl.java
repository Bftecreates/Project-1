package edu.utdallas.taskExecutorImpl;

import edu.utdallas.taskExecutor.Task;
import edu.utdallas.taskExecutor.TaskExecutor;

public class TaskExecutorImpl implements TaskExecutor
{
	TaskRunner[] runnerPool;
	BlockingQueue queue; 
	
	public TaskExecutorImpl(int threadPoolSize)
	{
		// TODO Complete the implementation
		queue = new BlockingQueue();
		
		runnerPool = new TaskRunner [threadPoolSize];
		
		for (int i=0; i < threadPoolSize; i++ )
		{
			runnerPool[i] = new TaskRunner(queue);
			
			Thread t = new Thread(runnerPool[i]);
			
			t.setName("TaskThread" + i);
			t.start();
		}
			
	}
	
	@Override
	public void addTask(Task task)
	{
		// TODO Complete the implementation
		queue.put(task);
		
	}
	class TaskRunner implements Runnable {
		BlockingQueue queue;
		
		public TaskRunner (BlockingQueue Blockqueue)
		{
			queue = Blockqueue;
		}
		
		public void run() {
		    while(true) {
		        // take() blocks if queue is empty
		        Task newTask = queue.take();
		        try {
		            newTask.execute();
		        }
		        catch(Throwable th) {
		           // Log (e.g. print exception’s message to console) 
		           // and drop any exceptions thrown by the task’s
		           // execution.
		        	System.out.println(th.getMessage());
		        }
		    }
		}

	}
	
	class BlockingQueue
	{
		int N= 100;
		
		Task buffer[]= new Task[N];
		
		int nextin, nextout =0;
		int count = 0;
		Object notfull = new Object();
		Object notempty = new Object(); // Monitors used for synchronization

		void put(Task task) 
		{
			synchronized (notfull) {
				
			  if(count == N) {
				  try {
					notfull.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}   // Buffer is full, wait for take
			  }
			}
			
		  buffer[nextin] = task;
		  nextin = (nextin + 1) % N;
		  count++;
		  
		  synchronized(notempty) {
			  notempty.notify();
		  }

		  //notempty.notify(); // Signal waiting take threads
		}

		Task take() 
		{
			synchronized (notempty)
			{
			  if(count == 0) {
				  try {
					notempty.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} // Buffer is empty, wait for put
			  }
			}
			  Task result = buffer[nextout];
			  nextout = (nextout + 1) % N;
			  count--;
			  
			  synchronized(notfull) {
	
			  notfull.notify(); // Signal waiting put threads
			  }
			  return result;
			
			}
		}

}
